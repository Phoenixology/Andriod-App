package com.example.projectwalton196.ViewModel;
import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.projectwalton196.Database.StudentManagementRepository;
import com.example.projectwalton196.Entities.CourseEntity;

import java.util.List;

public class CourseViewModel extends AndroidViewModel {

    int termId;
    private StudentManagementRepository mRepository;
    private LiveData<List<CourseEntity>> mAssociatedCourses;
    private LiveData<List<CourseEntity>> mAllCourses;
    public CourseViewModel(Application application, int termId){
        super(application);
        mRepository=new StudentManagementRepository(application);
        mAssociatedCourses=mRepository.getmAllAssociatedCourses(termId);
    }
    public CourseViewModel(Application application){
        super(application);
        mRepository=new StudentManagementRepository(application);
        mAllCourses=mRepository.getAllCourses();
        mAssociatedCourses=mRepository.getmAllAssociatedCourses(termId);
    }

    //public CourseViewModel(@NonNull Application application) {
      //  super(application);
   // }

    public LiveData<List<CourseEntity>> getAssociatedCourses(int termId){
        return mRepository.getmAllAssociatedCourses(termId);
    }
    public LiveData<List<CourseEntity>> getAllCourses(){
        return mAllCourses;
    }
    public void insert(CourseEntity courseEntity){ mRepository.insert(courseEntity);}
    public void delete(CourseEntity courseEntity){ mRepository.delete(courseEntity);}
   // public void delete( CourseEntity courseEntity) {mRepository.delete(mAllCourses);}
    public int lastID(){return mAllCourses.getValue().size();}




/*

    public void delete(CourseEntity p) {

    } */
}

