package com.example.projectwalton196;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectwalton196.Entities.CourseEntity;
import com.example.projectwalton196.Entities.TermEntity;
import com.example.projectwalton196.ViewModel.AssessmentViewModel;
import com.example.projectwalton196.ViewModel.CourseViewModel;
import com.example.projectwalton196.ViewModel.TermViewModel;
import com.example.projectwalton196.ui.CourseAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import android.widget.DatePicker;

import java.util.ArrayList;
import java.util.List;

public class CourseActivity<RESULT_Ok> extends AppCompatActivity {
    public static final int NEW_WORD_ACTIVITY_REQUEST_CODE = 1;
    // TODO contruct course view model
    private CourseViewModel mCourseViewModel;
    private TermViewModel mTermViewModel;
    private AssessmentViewModel mAssessmentViewModel;
    private EditText mEditCourseId;
    // int courseId, String courseTitle, int termId, int courseStartDate, int courseEndDate, int assessmentId,String courseStatus, String mentorInfo)
    private EditText mEditTermTitle;
    private EditText mEditTermId;
    //TODO is add dates and checkfor doubles vs integers in constructors
    private EditText mEditTermStartDate;
    private EditText mEditTermEndDate;
    private EditText mEditAssessmentId;
    private EditText startText;
    private static int numCourses;
    private int courseId;
    private String termTitle;
    //TODO is this needed
  //  private String courseString;
    final Calendar myCalendarStart = Calendar.getInstance();
    final Calendar myCalendarEnd = Calendar.getInstance();
    private EditText mTermStartDate;
    private EditText mTermEndDate;
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);// set as home display
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        mEditTermTitle = findViewById(R.id.editTermTitle);
        mEditTermId = findViewById(R.id.editTermId);
        mEditCourseId = findViewById(R.id.editCourseId);
        mEditTermStartDate = findViewById(R.id.editTermStartDate);
        mEditTermEndDate = findViewById(R.id.editTermEndDate);
        mEditAssessmentId = findViewById(R.id.editAssessmentId);
        mTermStartDate =findViewById(R.id.editTermStartDate);
        mTermEndDate =findViewById(R.id.editTermEndDate);
        // mEditStartDate=findViewById(R.id.ed)
        if (getIntent().getStringExtra("termTitle") != null) {
            mEditTermTitle.setText(getIntent().getStringExtra("termTitle"));
            mEditTermId.setText(Integer.toString(getIntent().getIntExtra("termId",0)));
      //      mEditCourseId.setText(Integer.toString(getIntent().getIntExtra("courseId",0)));
          //  mTermStartDate.setText(getIntent().getStringExtra("editTermStartDate"));
          //  mTermEndDate.setText(getIntent().getStringExtra("editTermEndDate"));
    //        mEditAssessmentId.setText(Integer.toString(getIntent().getIntExtra("assessmentId",0)));
          //  startText.setText(courseString);
 // TODO find what isn;t working in calander
            String myStart = getIntent().getStringExtra("termStartDate");
            String myEnd = getIntent().getStringExtra("termEndDate");
            mTermStartDate.setText(getIntent().getStringExtra("termStartDate"));
            mTermEndDate.setText(getIntent().getStringExtra("termEndDate"));
            String myFormat = "MM/dd/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date date = null;
            try {
                date = sdf.parse(myStart);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            myCalendarStart.setTime(date);
            try {
                date = sdf.parse(myEnd);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            myCalendarEnd.setTime(date);



        }
        /*
        mEditCourseId = findViewById(R.id.editCourseId);
        if (getIntent().getStringExtra("courseId") != null) {
            mEditCourseId.setText(getIntent().getStringExtra("courseId"));
        }
        */

        // TODO look at the conversion for any other strays
        mEditTermId = findViewById(R.id.editTermId);
        if (getIntent().getIntExtra("termId",0) !=0) {
            mEditTermId.setText(Integer.toString(getIntent().getIntExtra("termId",0)));
        }

// TODO i switched from mEditTermStartDate to mStartText
   //TODO     same with mEditTermEndDate

        mTermStartDate = findViewById(R.id.editTermStartDate);
        if (getIntent().getStringExtra("startDate") != null) {
            mTermStartDate.setText(getIntent().getStringExtra("startDate"));
        }
        mTermEndDate = findViewById(R.id.editTermEndDate);
        if (getIntent().getStringExtra("endDate") != null) {
            mTermEndDate.setText(getIntent().getStringExtra("endDate"));
        }
        /*
        mEditAssessmentId = findViewById(R.id.editAssessmentId);
        if (getIntent().getStringExtra("assessmentId") != null) {
            mEditAssessmentId.setText(getIntent().getStringExtra("assessmentId"));
        }


*/// TODO reconnect with non competing
        mTermStartDate = findViewById(R.id.editTermStartDate);
        startDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendarStart.set(Calendar.YEAR, year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }

        };


        mTermStartDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(CourseActivity.this, startDate, myCalendarStart
                        .get(Calendar.YEAR), myCalendarStart.get(Calendar.MONTH),
                        myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        mTermEndDate = findViewById(R.id.editTermEndDate);
        endDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                updateLabelEnd();
            }

        };

        mTermEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(CourseActivity.this, endDate, myCalendarEnd
                        .get(Calendar.YEAR), myCalendarEnd.get(Calendar.MONTH),
                        myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CourseActivity.this, AssessmentActivity.class);
                startActivityForResult(intent, NEW_WORD_ACTIVITY_REQUEST_CODE);

            }
        });


        RecyclerView recyclerView = findViewById(R.id.associated_courses);
        final CourseAdapter adapter = new CourseAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        mCourseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);
        mAssessmentViewModel = new ViewModelProvider(this).get(AssessmentViewModel.class);

        mTermViewModel = new ViewModelProvider(this).get(TermViewModel.class);
        mCourseViewModel.getAllCourses().observe(this, new Observer<List<CourseEntity>>() {
            @Override
            public void onChanged(@Nullable final List<CourseEntity> words) {
                List<CourseEntity> filteredWords = new ArrayList<>();
                int thisTerm=getIntent().getIntExtra("termId",0);
                for (CourseEntity p : words)
                    if (p.getTermId() == getIntent().getIntExtra("termId", 0))
                        filteredWords.add(p);
                adapter.setWords(filteredWords);
                numCourses = filteredWords.size();
            }
        });
        final Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent replyIntent = new Intent();
                String title = mEditTermTitle.getText().toString();
                int id = Integer.parseInt(mEditTermId.getText().toString());
                String termStartDate = mEditTermStartDate.getText().toString();
                String termEndDate = mEditTermEndDate.getText().toString();
                replyIntent.putExtra("termTitle", title);
                replyIntent.putExtra("termId", id);
                replyIntent.putExtra("termStartDate", termStartDate);
                replyIntent.putExtra("termEndDate", termEndDate);
           //     if (getIntent().getStringExtra("termTitle") != null) {
                    int courseId = getIntent().getIntExtra("termId", 0);
                    TermEntity term = new TermEntity(id, title, termStartDate, termEndDate);
                    mTermViewModel.insert(term);
          //      }
                setResult(RESULT_OK, replyIntent);
                finish();
            }
        });
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();// press
        return true;


    }
    private void updateLabelStart() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        mTermStartDate.setText(sdf.format(myCalendarStart.getTime()));
    }

    private void updateLabelEnd() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        mTermEndDate.setText(sdf.format(myCalendarEnd.getTime()));
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK) {
            //// int courseId, String courseTitle, int termId, int courseStartDate, int courseEndDate, int assessmentId,String courseStatus, String mentorInfo)

            CourseEntity course = new CourseEntity(mCourseViewModel.lastID()+1, "",0, "courseTitle", "", 0, "", "", "","","","","");
            mCourseViewModel.insert(course);
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_temp, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        if (id == R.id.action_settings){
            long trigger = myCalendarStart.getTimeInMillis();

            Intent intent=new Intent(CourseActivity.this,MyReceiver.class);
            intent.putExtra("termName",    mEditTermTitle.getText());
            intent.putExtra("message", "Term Starts Now");

            PendingIntent sender= PendingIntent.getBroadcast(CourseActivity.this,++MainActivity.numAlarms,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            return true;


           /* String start=startText.getText().toString();


            String myFormat = "MM/dd/yy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date mTermStartDate = null;
            try {
                mTermStartDate = sdf.parse(start);
            } catch (ParseException e) {
                e.printStackTrace();
            }
         //   myCalendarStart
        //    String s = mEditTermId.getText().toString();
         //  int val = Integer.parseInt(s);
            //  public TermEntity(int termID, String termTitle, String termStartDate, String termEndDate)
      //      TermEntity newTerm = new TermEntity(2, "", "", "");
         //   TermViewModel mTermViewModel = new ViewModelProvider(this).get(TermViewModel.class);
       //     mTermViewModel.insert(newTerm);
           // return true;

            */
        }

        if (id == R.id.action_settings){
            long trigger = myCalendarEnd.getTimeInMillis();

            Intent intent=new Intent(CourseActivity.this,MyReceiver.class);
            intent.putExtra("termName",    mEditTermTitle.getText());
            intent.putExtra("message", "Term Ends Now");

            PendingIntent sender= PendingIntent.getBroadcast(CourseActivity.this,++MainActivity.numAlarms,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            return true;


           /* String start=startText.getText().toString();


            String myFormat = "MM/dd/yy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date mTermStartDate = null;
            try {
                mTermStartDate = sdf.parse(start);
            } catch (ParseException e) {
                e.printStackTrace();
            }
         //   myCalendarStart
        //    String s = mEditTermId.getText().toString();
         //  int val = Integer.parseInt(s);
            //  public TermEntity(int termID, String termTitle, String termStartDate, String termEndDate)
      //      TermEntity newTerm = new TermEntity(2, "", "", "");
         //   TermViewModel mTermViewModel = new ViewModelProvider(this).get(TermViewModel.class);
       //     mTermViewModel.insert(newTerm);
           // return true;

            */
        }

        if (id == R.id.action_settings1){
            String end=endDate.toString();


            String myFormat = "MM/dd/yy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date mTermEndDate = null;
            try {
                mTermEndDate = sdf.parse(end);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            String s = mEditTermId.getText().toString();
            int val = Integer.parseInt(s);
            //  public TermEntity(int termID, String termTitle, String termStartDate, String termEndDate)
            TermEntity newTerm = new TermEntity(2, "", "", "");
            TermViewModel mTermViewModel = new ViewModelProvider(this).get(TermViewModel.class);
            mTermViewModel.insert(newTerm);
            return true;
        }


        //noinspection SimplifiableIfStatement
        if (id == R.id.delete) {
            if(numCourses==0) {
                mTermViewModel.getAllTerms().observe(this, new Observer<List<TermEntity>>() {
                    @Override
                    public void onChanged(@Nullable final List<TermEntity> words) {
                        // Update the cached copy of the words in the adapter.
                        List<TermEntity> filteredWords = new ArrayList<>();
                        for (TermEntity p : words)
                            if (p.getTermId() == getIntent().getIntExtra("termId", 0))
//                                filteredWords.add(p);
                                mTermViewModel.delete(p);
                        Toast.makeText(getApplicationContext(),"Term Deleted",Toast.LENGTH_LONG).show();
//                        // make a toast
//                        //adapter.setWords(words);
                    }
                });
            }
            else{
                Toast.makeText(getApplicationContext(),"Can't delete a term with courses",Toast.LENGTH_LONG).show();// make another toast
            }
        }

        if (id == R.id.action_settings3) {
            Intent intent=new Intent(CourseActivity.this,MyReceiver.class);
            PendingIntent sender= PendingIntent.getBroadcast(CourseActivity.this,++MainActivity.numAlarms,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+1000, sender);
            return true;
        }
        if (id == R.id.action_settings4) {
            Intent intent=new Intent(CourseActivity.this,MyReceiver.class);
            PendingIntent sender= PendingIntent.getBroadcast(CourseActivity.this,++MainActivity.numAlarms,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+1000, sender);
            return true;

         /*
                    PendingIntent sender= PendingIntent.getBroadcast(CourseActivity.this,0,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            return true;
//TODO has to include send message inside
          */
            // chaneg the time it goes off / triggers
        }

        //noinspection SimplifiableIfStatement
        if (id == R.id.settings){
            //   if (id == R.id.action_settings)
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
}
