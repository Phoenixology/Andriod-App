package com.example.projectwalton196.Entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
//public class CourseEntity {

@Entity(tableName="course_table")
public class CourseEntity {
    @PrimaryKey
    private int courseId;
  //  private String startDate;
 //   private String endDate;

    private String courseTitle;
    private String courseStartDate;
    private String courseEndDate;
    private int termId;
    private int assessmentId;
    private String courseStatus;
    private String mentorPhone;
    private String mentorPhone2;
    private String mentorName;
    private String mentorName2;
    private String mentorEmail;
    private String mentorEmail2;



    // //( int courseId, String courseTitle, int termId, int courseStartDate, int courseEndDate, int assessmentId,String courseStatus, String mentorName, String mentorName2, String mentorPhone, String mentorPhone2, String mentorEmail, string mentorEmail2)
    @Override
    public String toString() {
        return "CourseEntity{" +
                ", courseId = " + courseId +
         //       ", startDate =" + startDate +
           //     ", endDate ="  + endDate+
                ",courseTitle=" + courseTitle +
                ",termId=" + termId +
                ", courseStartDate=" + courseStartDate + '\'' +
                ", courseEndDate=" + courseEndDate +
                ", assessmentId=" + assessmentId +
                ",courseStatus=" + courseStatus +
                ",mentorName=" + mentorName +
                ", mentorName2 ="+ mentorName2+
                ", mentorPhone= " + mentorPhone+
                ", mentorPhone2 =" + mentorPhone2 +
                ", mentorEmail =" + mentorEmail +
                ", mentorEmail2 =" + mentorEmail2 +
                '}';
    }

    public CourseEntity( int courseId,  String courseTitle, int termId,  String courseStartDate, String courseEndDate, int assessmentId,String courseStatus, String mentorName, String mentorName2, String mentorPhone, String mentorPhone2, String mentorEmail, String mentorEmail2) {
        this.courseId = courseId;
     //   this.startDate = startDate;
 //       this.endDate = endDate;
        this.courseTitle = courseTitle;
        this.termId = termId;
        this.courseStartDate = courseStartDate;
        this.courseEndDate = courseEndDate;
        this.assessmentId = assessmentId;
        this.courseStatus = courseStatus;
        this.mentorName = mentorName;
        this.mentorName2 =mentorName2;
        this.mentorPhone= mentorPhone;
        this.mentorPhone2= mentorPhone2;
        this.mentorEmail=mentorEmail;
        this.mentorEmail2=mentorEmail2;

    }
    public int getCourseId() {return courseId;}

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public int getTermId() {
        return termId;
    }



    public void setTermId(int termId) {
        this.termId = termId;
    }

    public int getAssessmentId() {
        return assessmentId;
    }

    public void setAssessmentId(int assessmentId) {
        this.assessmentId = assessmentId;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;}


    public String getCourseStartDate() { return courseStartDate;}


    public String getMentorPhone() {
        return mentorPhone;
    }

    public void setMentorPhone(String mentorPhone) {
        this.mentorPhone = mentorPhone;
    }

    public String getMentorPhone2() {
        return mentorPhone2;
    }

    public void setMentorPhone2(String mentorPhone2) {
        this.mentorPhone2 = mentorPhone2;
    }

    public String getMentorName() {
        return mentorName;
    }

    public void setMentorName(String mentorName) {
        this.mentorName = mentorName;
    }

    public String getMentorName2() {
        return mentorName2;
    }

    public void setMentorName2(String mentorName2) {
        this.mentorName2 = mentorName2;
    }

    public String getMentorEmail() {
        return mentorEmail;
    }

    public void setMentorEmail(String mentorEmail) {
        this.mentorEmail = mentorEmail;
    }

    public String getMentorEmail2() {
        return mentorEmail2;
    }

    public void setMentorEmail2(String mentorEmail2) {
        this.mentorEmail2 = mentorEmail2;
    }

    public void setCourseStartDate(String courseStartDate) {
        this.courseStartDate = courseStartDate;}

    public String getCourseEndDate() { return courseEndDate;}


    public void setCourseEndDate(String courseEndDate){
            this.courseEndDate = courseEndDate;}


    public String getCourseStatus() {
        return courseStatus;
    }
    public void setCourseStatus(String courseStatus) {
        this.courseStatus = courseStatus;}














    }




