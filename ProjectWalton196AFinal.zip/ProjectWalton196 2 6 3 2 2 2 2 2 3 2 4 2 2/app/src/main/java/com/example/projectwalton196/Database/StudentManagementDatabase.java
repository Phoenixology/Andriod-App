package com.example.projectwalton196.Database;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.projectwalton196.DAO.Assessments;
import com.example.projectwalton196.DAO.Course;
import com.example.projectwalton196.DAO.Term;
import com.example.projectwalton196.Entities.AssessmentEntity;
import com.example.projectwalton196.Entities.CourseEntity;
import com.example.projectwalton196.Entities.TermEntity;

//import com.example.p.DAO.AssessmentsDAO;

@Database(entities = {AssessmentEntity.class, CourseEntity.class, TermEntity.class}, version = 8,
exportSchema = false)
public abstract class StudentManagementDatabase extends RoomDatabase {

    public abstract Assessments assessmentsDAO();

    public abstract Course courseDAO();

    public abstract Term termDAO();


    private static volatile StudentManagementDatabase INSTANCE;

    static StudentManagementDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (StudentManagementDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), StudentManagementDatabase.class, "student_management_database")
                            .fallbackToDestructiveMigration()
                            .addCallback(sRoomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback sRoomDatabaseCallback = new RoomDatabase.Callback() {

        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
            // If you want to keep the data through app restarts,
            // comment out the following line.
            new PopulateDbAsync(INSTANCE).execute();
        }
    };

    /**
     * Populate the database in the background.
     * If you want to start with more words, just add them.
     */
    private static class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

        private final Assessments mAssessmentsDao;
        private final Course mCourseDao;
        private final Term mTermDao;

        PopulateDbAsync(StudentManagementDatabase db) {
            mAssessmentsDao = db.assessmentsDAO();
            mCourseDao = db.courseDAO();
            mTermDao = db.termDAO();


        }

        @Override
        protected Void doInBackground(final Void... params) {
            // Start the app with a clean database every time.
            // Not needed if you only populate on creation.
              mTermDao.deleteAllTerms();
              mCourseDao.deleteAll();
              mAssessmentsDao.deleteAll();


            TermEntity term = new TermEntity(1, "Focus Term","08/05/20", "12/05/20" );
            mTermDao.insert(term);
            term = new TermEntity(2,"Explorer Term", "12/05/20", "06/05/21");
            mTermDao.insert(term);
            term = new TermEntity(3,"Creator Term", "07/05/21", "01/05/21");
            mTermDao.insert(term);

   // y( int courseId,  String courseTitle, int termId, String courseStartDate, String courseEndDate, int assessmentId,String courseStatus, String mentorName, String mentorName2, String mentorPhone, String mentorPhone2, String mentorEmail, String mentorEmail2)

            CourseEntity course = new CourseEntity(101, "Algorithm Alchemy",1, "08/05/20","12/05/20",1010,"Completed","Bear","Sun Shining","111 333 4444","222 333 4444","ownyourcrown@shinebrightly.org","ownyourcrown@shinebrightly2.org");
            mCourseDao.insert(course);
            course = new CourseEntity(201,"Java data structures",2, "12/05/20","6/05/21",2010,"in progress","Hal","Moon Reflecting", "333 888 1111","","dropWithin@innerreflection.net","4dropWithin@innerreflection.net");
            mCourseDao.insert(course);
            course = new CourseEntity(301,"Deno details",3, "07/05/21","02/05/21",3010,"plan to take","James","Bee Beeing", " 888 999 7777","777 888 9999","beeBeeing@honey.org","2beeBeeing@honey.org");
            mCourseDao.insert(course);
//int courseId, int assessmentId, String assessmentTitle, int courseDueDate, String courseNotes, String sharingFeatures)
            AssessmentEntity assessment = new AssessmentEntity(1010, "Inside Search Algorithms", " Performance","In house" ,101,"09/05/20","Look from the Harrier Hawk View before starting","email","08/20/20");
            mAssessmentsDao.insert(assessment);
            assessment = new AssessmentEntity(2010, "Data Structures for robotic searches", "Both "," in House",201, "10/02/20","Build it like Tesla used to","use email","09/20/20");
            mAssessmentsDao.insert(assessment);
            assessment = new AssessmentEntity(3010, "AI & Java ", " Objective","In house",301, "11/05/20","Inside your quest are the answers","use email","10/15/20");
            mAssessmentsDao.insert(assessment);

            return null;

        }
    }
}