package com.example.projectwalton196.ui;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.projectwalton196.AssessmentActivity;
import com.example.projectwalton196.Entities.CourseEntity;
import com.example.projectwalton196.R;

import java.util.List;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder>  {
    class CourseViewHolder extends RecyclerView.ViewHolder {

    private final TextView courseItemView;
    private final TextView courseItemView2;


    private CourseViewHolder(View itemView) {
        super(itemView);
        courseItemView = itemView.findViewById(R.id.courseTextView);
        courseItemView2 = itemView.findViewById(R.id.courseTextView2);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //// //( int courseId, String courseTitle, int termId, int courseStartDate, int courseEndDate, int assessmentId,String courseStatus, String mentorName, String mentorName2, String mentorPhone, String mentorPhone2, String mentorEmail, string mentorEmail2)
                int position = getAdapterPosition();
                final CourseEntity current = mCourse.get(position);
                Intent intent = new Intent(context, AssessmentActivity.class);
                intent.putExtra("courseId", current.getCourseId());
          //      intent.putExtra("startDate", current.getStartDate());
           //     intent.putExtra("endDate", current.getEndDate());
                intent.putExtra("courseTitle", current.getCourseTitle());
                intent.putExtra("termId", current.getTermId());
                intent.putExtra("courseStartDate", current.getCourseStartDate());
                intent.putExtra("courseEndDate", current.getCourseEndDate());
                intent.putExtra("assessmentId",current.getAssessmentId());
                intent.putExtra("courseStatus",current.getCourseStatus());
                intent.putExtra("mentorName",current.getMentorName());
                intent.putExtra("mentorName2", current.getMentorName2());
                intent.putExtra("mentorPhone", current.getMentorPhone());
                intent.putExtra("mentorPhone2",current.getMentorPhone2());
                intent.putExtra("mentorEmail", current.getMentorEmail());
                intent.putExtra("mentorEmail2", current.getMentorEmail2());
                intent.putExtra("position",position);


                context.startActivity(intent);
            }
        });
    }

}

    private final LayoutInflater mInflater;
    private final Context context;
    private List<CourseEntity> mCourse; // Cached copy of words

    public CourseAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context=context;
    }

    @Override
    public CourseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.course_list_item,parent,false);//course_list_item, parent, false);

        return new CourseViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(CourseViewHolder holder, int position) {
        if (mCourse != null) {
            CourseEntity current = mCourse.get(position);
            holder.courseItemView.setText(current.getCourseTitle());
            holder.courseItemView2.setText(Integer.toString(current.getTermId()));
        } else {
            // Covers the case of data not being ready yet.
            holder.courseItemView.setText("No Word");
            holder.courseItemView2.setText("No Word");
        }

    }

    public void setWords(List<CourseEntity> words) {
        mCourse = words;
        notifyDataSetChanged();
    }

    // getItemCount() is called many times, and when it is first called,
    // mWords has not been updated (means initially, it's null, and we can't return null).
    @Override
    public int getItemCount() {
        if (mCourse != null)
            return mCourse.size();
        else return 0;
    }

}
