package com.example.projectwalton196;


import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.example.projectwalton196.Entities.CourseEntity;
import com.example.projectwalton196.Entities.AssessmentEntity;
import com.example.projectwalton196.ViewModel.AssessmentViewModel;
import com.example.projectwalton196.ui.AssessmentAdapter;
import com.example.projectwalton196.ViewModel.CourseViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import android.widget.DatePicker;


public class AssessmentActivity extends AppCompatActivity {
    public static final int NEW_WORD_ACTIVITY_REQUEST_CODE = 1;
    final Calendar myCalendarStart = Calendar.getInstance();
    final Calendar myCalendarEnd = Calendar.getInstance();
    EditText startText;
    EditText endText;
    DatePickerDialog.OnDateSetListener startDate;
    DatePickerDialog.OnDateSetListener endDate;

    private AssessmentViewModel mAssessmentViewModel; //mAssessmentViewModel;
    private CourseViewModel mCourseViewModel;
    public static int numAssessments;
    public static final String EXTRA_REPLY = "com.walton.tester.wordlistsql.REPLY";
 //( int courseId, String courseTitle, int termId, int courseStartDate, int courseEndDate, int assessmentId,String courseStatus, String mentorName, String mentorName2, String mentorPhone, String mentorPhone2, String mentorEmail, string mentorEmail2)
    private EditText mEditCourseId;
    private EditText mEditCourseTitle;
    private EditText mTermId;
    private EditText mCourseStartDate;
    private EditText mCourseEndDate;
    private EditText mAssessmentId;
    private EditText mCourseStatus;
    private EditText mMentorName;
    private EditText mMentorName2;
    private EditText mMentorPhone;
    private EditText mMentorPhone2;
    private EditText mMentorEmail;
    private EditText mMentorEmail2;
    private int position;
    private String courseStartDate;
    private String courseEndDate;
    private EditText termId;
    private CourseEntity thisCourse;
    private Date startDate2;
    private Date endDate1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment);
        mAssessmentViewModel = new ViewModelProvider(this).get(AssessmentViewModel.class);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);// set as home display
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        mEditCourseTitle = findViewById(R.id.editTitle);
        mEditCourseId= findViewById(R.id.editCourseId);
        mTermId = findViewById(R.id.editTermId);
        mCourseStartDate = findViewById(R.id.editCourseStartDate);
        mCourseEndDate = findViewById(R.id.editCourseEndDate);
        mAssessmentId = findViewById(R.id.editAssessmentId);
        mCourseStatus =findViewById(R.id.editCourseStatus);
        mMentorName = findViewById(R.id.editMentorName);
        mMentorName2 = findViewById(R.id.editMentorName2);
        mMentorPhone =findViewById(R.id.editMentorPhone);
        mMentorPhone2 =findViewById(R.id.editMentorPhone2);
        mMentorEmail=findViewById(R.id.editMentorEmail);
        mMentorEmail2 =findViewById(R.id.editMentorEmail2);
        String s = getIntent().getStringExtra("courseTitle");

        if (getIntent().getStringExtra("courseTitle") != null) {
            mEditCourseTitle.setText(getIntent().getStringExtra("courseTitle"));
            mEditCourseId.setText(Integer.toString(getIntent().getIntExtra("courseId",0)));
            mTermId.setText(Integer.toString(getIntent().getIntExtra("termId",0)));
            mCourseStartDate.setText(getIntent().getStringExtra("courseStartDate"));
            mCourseEndDate.setText(getIntent().getStringExtra("courseEndDate"));
            mAssessmentId.setText(Integer.toString(getIntent().getIntExtra("assessmentId",0)));
            mCourseStatus.setText(getIntent().getStringExtra("courseStatus"));
            mMentorName.setText(getIntent().getStringExtra("mentorName"));
            mMentorName2.setText(getIntent().getStringExtra("mentorName2"));
            mMentorPhone.setText(getIntent().getStringExtra("mentorPhone"));
            mMentorPhone2.setText(getIntent().getStringExtra("mentorPhone2"));
            mMentorEmail.setText(getIntent().getStringExtra("mentorEmail"));
            mMentorEmail2.setText(getIntent().getStringExtra("mentorEmail2"));
        }
        mAssessmentId = findViewById(R.id.editAssessmentId);
        mCourseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);
 /*       mCourseViewModel.getAllCourses().observe(this, new Observer<List<CourseEntity>>() {
            @Override
            public void onChanged(@Nullable final List<CourseEntity> words) {
                // Update the cached copy of the words in the adapter.
                List<CourseEntity> filteredWords = new ArrayList<>();
                for (CourseEntity p : words)
                    if (p.getCourseId() == getIntent().getIntExtra("courseId", 0))
//                                filteredWords.add(p);
                        thisCourse =p;
                Toast.makeText(getApplicationContext(),"Course Deleted",Toast.LENGTH_LONG).show();

//                        // make a toast
//                        //adapter.setWords(words);
            }
        }); */
         // mEditCourseStartDate.setText();
       mCourseStartDate = findViewById(R.id.editCourseStartDate);
        startDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendarStart.set(Calendar.YEAR, year);
                myCalendarStart.set(Calendar.MONTH, monthOfYear);
                myCalendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }

        };

        mCourseStartDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AssessmentActivity.this, startDate, myCalendarStart
                        .get(Calendar.YEAR), myCalendarStart.get(Calendar.MONTH),
                        myCalendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


        mCourseEndDate = findViewById(R.id.editCourseEndDate);
        endDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendarEnd.set(Calendar.YEAR, year);
                myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                updateLabelEnd();
            }

        };

        mCourseEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AssessmentActivity.this, endDate, myCalendarEnd
                        .get(Calendar.YEAR), myCalendarEnd.get(Calendar.MONTH),
                        myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });




        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AssessmentActivity.this, Assessment_Detail.class);
                startActivityForResult(intent, NEW_WORD_ACTIVITY_REQUEST_CODE);
            }
        });


        mAssessmentViewModel = new ViewModelProvider(this).get(AssessmentViewModel.class);
        mCourseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);

        RecyclerView recyclerView = findViewById(R.id.associated_assessments);
        final AssessmentAdapter adapter = new AssessmentAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //mPartViewModel = ViewModelProviders.of(this).get(PartViewModel.class);
        mAssessmentViewModel = new ViewModelProvider(this).get(AssessmentViewModel.class);

        //YourViewModel viewModel = new ViewModelProvider(this).get(YourViewModel.class)
        mAssessmentViewModel.getAllAssessments().observe(this, new Observer<List<AssessmentEntity>>() {

            @Override
            public void onChanged(@Nullable final List<AssessmentEntity> words) {
                List<AssessmentEntity> filteredWords = new ArrayList<>();
                int thisAssessment=getIntent().getIntExtra("assessmentId",0);
                for (AssessmentEntity p : words)
                {
                    int myCourseId = getIntent().getIntExtra("courseId", 0);
                int filterID = p.getCourseId();

                    if (p.getCourseId() == getIntent().getIntExtra("courseId", 0))
                        filteredWords.add(p);}
                adapter.setWords(filteredWords);
                numAssessments = filteredWords.size();
                //adapter.setWords(words);
            }
        });
        /*
              public void onChanged(@Nullable final List<CourseEntity> words) {
                List<CourseEntity> filteredWords = new ArrayList<>();
                int thisTerm=getIntent().getIntExtra("termId",0);
                for (CourseEntity p : words)
                    if (p.getTermId() == getIntent().getIntExtra("termId", 0))
                        filteredWords.add(p);
                adapter.setWords(filteredWords);
                numCourses = filteredWords.size();
            }
         */


        final Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent replyIntent = new Intent();
                String title = mEditCourseTitle.getText().toString();
                //int id =  Integer.toString(mEditId.getText().;)getIntent().getIntExtra(mEditId.getText().toString());
                int id = Integer.parseInt(mEditCourseId.getText().toString());
            //    String startDate = mEditCourseStartDate.getText().toString();
            //    String endDate = mEditCourseEndDate.getText().toString();
                String courseTitle = mEditCourseTitle.getText().toString();
                int termId = Integer.parseInt(mTermId.getText().toString());
           //     termId =  mTermId.getId();

                courseStartDate = mCourseStartDate.getText().toString();
                courseEndDate = mCourseEndDate.getText().toString();
                int assessmentId = Integer.parseInt( mAssessmentId.getText().toString());
                String courseStatus = mCourseStatus.getText().toString();
                String mentorName = mMentorName.getText().toString();
                String mentorName2 = mMentorName2.getText().toString();
                String mentorPhone = mMentorPhone.getText().toString();
                String mentorPhone2 = mMentorPhone2.getText().toString();
                String mentorEmail = mMentorEmail.getText().toString();
                String mentorEmail2 = mMentorEmail2.getText().toString();
                replyIntent.putExtra("courseTitle", title);
                replyIntent.putExtra("courseId", id);
            //    replyIntent.putExtra("startDate", startDate);
           //     replyIntent.putExtra("endDate", endDate);
                replyIntent.putExtra("termId", termId);
                replyIntent.putExtra("courseStartDate",courseStartDate);
                replyIntent.putExtra("courseEndDate", courseEndDate);
                replyIntent.putExtra("assessmentId", assessmentId);
                replyIntent.putExtra("courseStatus", courseStatus);
                replyIntent.putExtra("mentorName", mentorName);
                replyIntent.putExtra("mentorName2", mentorName2);
                replyIntent.putExtra("mentorPhone", mentorPhone);
                replyIntent.putExtra("mentorPhone2", mentorPhone2);
                replyIntent.putExtra("mentorEmail", mentorEmail);
                replyIntent.putExtra("mentorEmail2", mentorEmail2); {
                    int id2 = getIntent().getIntExtra("courseID", 0);
                    //CourseEntity( int courseId, String courseTitle, int termId, int courseStartDate, int courseEndDate, int assessmentId,String courseStatus, String mentorInfo)
                    CourseEntity course = new CourseEntity(id, courseTitle,termId,courseStartDate, courseEndDate, assessmentId, courseStatus, mentorName,mentorName2,mentorPhone,mentorPhone2,mentorEmail,mentorEmail2);
                    mCourseViewModel.insert(course);
                }
                setResult(RESULT_OK, replyIntent);
                finish();
            }

        });

    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();// press
        return true;


    }
    private void updateLabelStart() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        mCourseStartDate.setText(sdf.format(myCalendarStart.getTime()));
    }

    private void updateLabelEnd() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        mCourseEndDate.setText(sdf.format(myCalendarEnd.getTime()));
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult((requestCode), resultCode, data);
        if (requestCode == RESULT_OK) {
//public AssessmentEntity( int assessmentId, String assessmentTitle ,String objectiveAssessment, String performanceAssessment,int courseId, int courseDueDate, String courseNotes, String sharingFeatures, String setAlert)
            AssessmentEntity assessment = new AssessmentEntity(mCourseViewModel.lastID() + 1, "", data.getStringExtra("objectiveAssessment"), data.getStringExtra("performanceAssessment"), data.getIntExtra("courseId",0),"","","","");
            mAssessmentViewModel.insert(assessment);

        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_assessment, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        int idActionSettings = R.id.action_settings;
        int idActionSettings1 = R.id.action_settings1;
        int idDelete = R.id.deleteC;

        int idActionSettings2 = R.id.action_settings2;
        int idActionSettings3 = R.id.action_settings3;





        if (id == R.id.action_settings) {
            String myFormat = "MM/dd/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myDate = null;
            try {
                myDate = sdf.parse(mCourseStartDate.getText().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            myCalendarStart.setTime(myDate);


            long trigger = myCalendarStart.getTimeInMillis();

            Intent intent=new Intent(AssessmentActivity.this,MyReceiver.class);
            intent.putExtra("courseName",    mEditCourseTitle.getText());
            intent.putExtra("message", "Course Starts Now");

            PendingIntent sender= PendingIntent.getBroadcast(AssessmentActivity.this,++MainActivity.numAlarms,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
         //   return true;

           // String startDate =startDate.getText.toString();

         //   String myFormat2 = "MM/dd/yy";
         //  SimpleDateFormat sdf = new SimpleDateFormat(myFormat2, Locale.US);
            Date startDate2= null;
            try {
                startDate2= sdf.parse(mCourseStartDate.getText().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            String s=mEditCourseId.getText().toString();
            int val=Integer.parseInt(s);
            //  y( int courseId,  String courseTitle, int termId, String courseStartDate, String courseEndDate, int assessmentId,String courseStatus, String mentorName, String mentorName2, String mentorPhone, String mentorPhone2, String mentorEmail, String mentorEmail2)
            CourseEntity newCourse=new CourseEntity( 0,"",0,"", "",0,"","","","","","","");
            CourseViewModel mCourseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);
            mCourseViewModel.insert(newCourse);
            return true;



        }
        if (id == R.id.action_settings1) {
            String myFormat = "MM/dd/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myDate1 = null;
            try {
                myDate1 = sdf.parse(mCourseEndDate.getText().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            myCalendarEnd.setTime(myDate1);


            long trigger = myCalendarEnd.getTimeInMillis();

            Intent intent=new Intent(AssessmentActivity.this,MyReceiver.class);
            intent.putExtra("courseName",    mEditCourseTitle.getText());
            intent.putExtra("message", "Course Ends");

            PendingIntent sender= PendingIntent.getBroadcast(AssessmentActivity.this, ++MainActivity.numAlarms,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            //   return true;

            // String startDate =startDate.getText.toString();

          //  String myFormat = "MM/dd/yy";
         //   SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

            Date endDate1= null;
            try {
                endDate1 = sdf.parse(mCourseEndDate.getText().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }

            String s=mEditCourseId.getText().toString();
            int val=Integer.parseInt(s);
            //  y( int courseId,  String courseTitle, int termId, String courseStartDate, String courseEndDate, int assessmentId,String courseStatus, String mentorName, String mentorName2, String mentorPhone, String mentorPhone2, String mentorEmail, String mentorEmail2)
            CourseEntity newCourse=new CourseEntity( 0,"",0,"", "",0,"","","","","","","");
            CourseViewModel mCourseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);
            mCourseViewModel.insert(newCourse);
            return true;



        }

                if (id == R.id.deleteC) {
                    Toast.makeText(this,"this is where we delete",Toast.LENGTH_LONG).show();
        //    if(numCourses==0) {
                    mCourseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);
                mCourseViewModel.getAllCourses().observe(this, new Observer<List<CourseEntity>>() {
                    @Override
                    public void onChanged(@Nullable final List<CourseEntity> words) {
                        // Update the cached copy of the words in the adapter.
                        List<CourseEntity> filteredWords = new ArrayList<>();
                        for (CourseEntity p : words)
                            if (p.getCourseId() == getIntent().getIntExtra("courseId", 0))
//                                filteredWords.add(p);
                                mCourseViewModel.delete(p);
                        Toast.makeText(getApplicationContext(),"Course Deleted",Toast.LENGTH_LONG).show();

//                        // make a toast
//                        //adapter.setWords(words);
                    }
                });
         //   mCourseViewModel.delete(thisCourse);
            }
        if (id == R.id.action_settings2) {
            Intent intent=new Intent(AssessmentActivity.this,MyReceiver.class);
            PendingIntent sender= PendingIntent.getBroadcast(AssessmentActivity.this,++MainActivity.numAlarms,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+1000, sender);
            return true;
        }
        if (id == R.id.action_settings3) {
            Intent intent = new Intent(AssessmentActivity.this, MyReceiver.class);
            PendingIntent sender = PendingIntent.getBroadcast(AssessmentActivity.this, ++MainActivity.numAlarms, intent, 0);
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1000, sender);
            return true;
        }

         /*





        //noinspection SimplifiableIfStatement
      // if (id == R.id.deleteC) {
       //     Toast.makeText(this,"this is where we delete",Toast.LENGTH_LONG);
       // }
      /*     if(numAssessments==0) {
                mCourseViewModel.getAllCourses().observe(this, new Observer<List<CourseEntity>>() {

                    @Override
                    public void onChanged(@Nullable final List<CourseEntity> words) {
                        // Update the cached copy of the words in the adapter.
                        int thisAssessment=getIntent().getIntExtra("assessmentId",0);
                        List<CourseEntity> filteredWords = new ArrayList<>();
                        for (CourseEntity p : words)
                            if (p.getCourseId() == getIntent().getIntExtra("courseId", 0))
//                                filteredWords.add(p);
                                mCourseViewModel.delete(p);
                        Toast.makeText(getApplicationContext(),"Course Deleted",Toast.LENGTH_LONG).show();
//                        // make a toast
//                        //adapter.setWords(words);
                    }
                });
            }
            else{
                Toast.makeText(getApplicationContext(),"Can't delete a course with assessments",Toast.LENGTH_LONG).show();// make another toast
            }
        }
*/
        if (id == R.id.settings){
            //   if (id == R.id.action_settings)
            return true;
        }


        return super.onOptionsItemSelected(item);
    }
/*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.delete) {
            if (numAssessments == 0) {
                mCourseViewModel.getAllCourses().observe(this, new Observer<List>CourseEntity>>(){
                    @Override
                    public void onChanged(@Nullable final List<CourseEntity> words){
                        List<CourseEntity> filteredWords = new ArrayList<>();
                        for (CourseEntity p : words)
                            if (p.getCourseId() == getIntent().getIntExtra("courseId", 0))
                                filteredWords.add(p);
                        //  courseViewModel.delete(p);
                        Toast.makeText(getApplicationContext(), "Course Deleted ", Toast.LENGTH_LONG).show();
                    }
                });
            } else {
                Toast.makeText(getApplicationContext(), " Can't delete a course with assessments", Toast.LENGTH_LONG).show();
            }
        }
        return super.onOptionsItemSelected(item);


    }

 */
}


