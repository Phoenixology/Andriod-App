package com.example.projectwalton196;

import android.app.DatePickerDialog;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import android.widget.DatePicker;
import android.widget.Toast;

import com.example.projectwalton196.Entities.AssessmentEntity;
import com.example.projectwalton196.ViewModel.AssessmentViewModel;

public class Assessment_Detail extends AppCompatActivity {
    public static final String EXTRA_REPLY = "com.walton.tester.wordlistsql.REPLY";
    //public AssessmentEntity( int assessmentId, String assessmentTitle ,String objectiveAssessment, String performanceAssessment,int courseId, int courseDueDate, String courseNotes, String sharingFeatures, String setAlert)
    private AssessmentViewModel mAssessmentViewModel;
    private static int numAssessments;

    private EditText mEditTitle;
    private EditText mEditAssessmentId;
    private EditText mEditCourseId;
    private int courseId;
    private EditText mObjectiveAssessment;
    private EditText mPerformanceAssessment;
    private EditText mAssessmentDueDate;
    private EditText mCourseNotes;
    private EditText mSharingFeatures;
    private EditText mSetAlert;
    private CalendarView picker;
    private EditText mEndDate;
    private EditText mEndText;
    private EditText mDueDate;
    private int position;
    private TextView mills;
    final Calendar myCalendarStart = Calendar.getInstance();
    final Calendar myCalendarEnd = Calendar.getInstance();
    EditText startText;
    EditText endText;
    EditText dueDate;
   // DatePickerDialog.OnDateSetListener dueDate;
    DatePickerDialog.OnDateSetListener endDate;
    // DatePickerDialog.OnDateSetListener endText;

    private String assessmentDueDate;
    long date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAssessmentViewModel = new ViewModelProvider(this).get(AssessmentViewModel.class);
        setContentView(R.layout.activity_assessment_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        mEditTitle = findViewById(R.id.editAssessmentTitle);//editAssess1); // needs updating
        mEditAssessmentId = findViewById(R.id.editAssessmentId);
        mObjectiveAssessment = findViewById(R.id.editObjectiveAssessment);
        mPerformanceAssessment = findViewById(R.id.editPerformanceAssessment);
        mEditCourseId = findViewById(R.id.editCourseId);
        mDueDate = findViewById(R.id.editDueDate);
       // mEndDate = findViewById(R.id.);
        mCourseNotes = findViewById(R.id.editCourseNotes);
        mSharingFeatures = findViewById(R.id.editSharingFeatures);
        mSetAlert = findViewById(R.id.editSetAlert);
        mills = findViewById(R.id.dateInMills1);
       // startText=findViewById(R.id.startDate);
       // endText = findViewById(R.id.editEndDate);
        //  picker = (CalendarView) findViewById(R.id.calendarView);
        //  String s = getIntent().getStringExtra("assessmentTitle");

        //  picker.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
   /*     endDate = new DatePickerDialog.onDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendarEnd = Calendar.getInstance();
                myCalendarEnd.set(year, month, dayOfMonth, 0, 0);
                mills.setText(Long.toString(c.getTimeInMillis()));
            }
        });
       endText.setOnClickListener(new View.OnClickListener() {


                                  @Override
                public void onClick(View v){
           new DatePickerDialog(Assessment_Detail.this,endDate, myCalendarEnd.get(Calendar.YEAR),myCalendarEnd.get(Calendar.MONTH),myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
        }
    */
        String temp = getIntent().getStringExtra("assessmentTitle");
        if (getIntent().getStringExtra("assessmentTitle") != null) {
            mEditTitle.setText(getIntent().getStringExtra("assessmentTitle"));
            mEditAssessmentId.setText(Integer.toString(getIntent().getIntExtra("assessmentId", 0)));
            mEditCourseId.setText(Integer.toString(getIntent().getIntExtra(("courseId"), 0)));
      //      endText.setText(getIntent().getStringExtra("endDate"));
            mDueDate.setText(getIntent().getStringExtra("dueDate"));
         //   mEndDate.setText(getIntent().getStringExtra("endDate"));
            mCourseNotes.setText(getIntent().getStringExtra("courseNotes"));
            mSharingFeatures.setText(getIntent().getStringExtra("sharingFeatures"));
            mSetAlert.setText(getIntent().getStringExtra("setAlert"));
            mPerformanceAssessment.setText(getIntent().getStringExtra("performanceAssessment"));
            mObjectiveAssessment.setText(getIntent().getStringExtra("objectiveAssessment"));
            //       startText.setText(assessmentString);

        }

    /*    mAssessmentViewModel.getAllAssessments().observe(this, new Observer<List<AssessmentEntity>>() {
            @Override
            public void onChanged(@Nullable final List<AssessmentEntity> words) {
                // Update the cached copy of the words in the adapter.
                List<AssessmentEntity> filteredWords = new ArrayList<>();
                for (AssessmentEntity p : words)
                    if (p.getAssessmentId() == getIntent().getIntExtra("assessmentId", 0))
//                                filteredWords.add(p);
                        mAssessmentViewModel.delete(p);
                Toast.makeText(getApplicationContext(), "Assessment Deleted", Toast.LENGTH_LONG).show();
//                        // make a toast
//                        //adapter.setWords(words);
            }
        }); */
        final Button button = findViewById(R.id.button_save);
        button.setOnClickListener((view) -> {
            //    mEditTitle.setText(getIntent().getStringExtra("assessmentTitle"));
            //  mEditAssessmentId.setText(Integer.toString(getIntent().getIntExtra("assessmentId", 0)));


            //    final Button button = findViewById(R.id.button_save);
            //        button.setOnClickListener(new View.OnClickListener() {
            Intent replyIntent = new Intent();
            String title = mEditTitle.getText().toString();
            int id = Integer.parseInt(mEditAssessmentId.getText().toString());
            int courseId = Integer.parseInt(mEditCourseId.getText().toString()); //;mEditCourseId.setText(Integer.toString(getIntent().getIntExtra(("courseId"), 0)));
         //   String dueDate = mEndDate.getText().toString(); // endText.setText(getIntent().getStringExtra("endDate"));
            String dueDate = mDueDate.getText().toString();        //mEndDate.setText(getIntent().getStringExtra("endDate"));
            String courseNotes = mCourseNotes.getText().toString(); //  mCourseNotes.setText(getIntent().getStringExtra("courseNotes"));
            String sharingFeatures = mSharingFeatures.getText().toString(); //tomSharingFeatures.setText(getIntent().getStringExtra("sharingFeatures"));
            String setAlert = mSetAlert.getText().toString();  //   mSetAlert.setText(getIntent().getStringExtra("setAlert"));
            String performanceAssessment = mPerformanceAssessment.getText().toString(); //  mPerformanceAssessment.setText(getIntent().getStringExtra("performanceAssessment"));
            String objectiveAssessment = mObjectiveAssessment.getText().toString(); // mObjectiveAssessment.setText(getIntent().getStringExtra("objectiveAssessment"));
            //   replyIntent.putExtra("assessmentTitle", title);
            // replyIntent.putExtra("assessmentId", id);
            //    if (getIntent().getStringExtra("assessmentTitle") != null) {
             /*   int assessmentId = getIntent().getIntExtra("assessmentId", 0);
                String assessmentTitle = getIntent().getStringExtra("assessmentTitle");
                String objectiveAssessment = getIntent().getStringExtra("objectiveAssessment");
                String performanceAssessment = getIntent().getStringExtra("performanceAssessment");
                int courseId = getIntent().getIntExtra("courseId", 0);
                //  courseEndDate = mEditCourseEndDate.getText().toString();
            //    assessmentDueDate = mCourseDueDate.getText().toString();
                String assessmentDueDate = getIntent().getStringExtra("assessmentDueDate");
                String courseNotes = getIntent().getStringExtra("courseNotes");
                String sharingFeatures = getIntent().getStringExtra("sharingFeatures");
           */  //   String setAlert = getIntent().getStringExtra("setAlert");
                replyIntent.putExtra("assessmentTitle", title);
                replyIntent.putExtra("assessmentId", id);
                replyIntent.putExtra("objectiveAssessment", objectiveAssessment);
                replyIntent.putExtra("performanceAssessment", performanceAssessment);
                replyIntent.putExtra(" courseId", courseId);
                replyIntent.putExtra("dueDate", dueDate);
                replyIntent.putExtra("courseNotes", courseNotes);
                replyIntent.putExtra("sharingFeatures", sharingFeatures);
                replyIntent.putExtra("setAlert", setAlert);


            AssessmentEntity assessment = new AssessmentEntity(id, title, objectiveAssessment, performanceAssessment, courseId,  dueDate, courseNotes, sharingFeatures, setAlert);


            mAssessmentViewModel.insert(assessment);
            setResult(RESULT_OK, replyIntent);
            finish();
            //    Intent intent = new Intent(this, CourseActivity.class);
            //    startActivity(intent);

            //   }
       //    endText = findViewById(R.id.editEndDate);
            mDueDate = findViewById(R.id.editDueDate);
            endDate = new DatePickerDialog.OnDateSetListener() {

                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear,
                                      int dayOfMonth) {
                    // TODO Auto-generated method stub
                    myCalendarEnd.set(Calendar.YEAR, year);
                    myCalendarEnd.set(Calendar.MONTH, monthOfYear);
                    myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    String myFormat = "MM/dd/yy"; //In which you need put here
                    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                    updateLabelEnd();
                }

            };
            mDueDate.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    new DatePickerDialog(Assessment_Detail.this, endDate, myCalendarEnd
                            .get(Calendar.YEAR), myCalendarEnd.get(Calendar.MONTH),
                            myCalendarEnd.get(Calendar.DAY_OF_MONTH)).show();
                }
            });

            setResult(RESULT_OK, replyIntent);
            finish();
        });
        //     super.onCreate(savedInstanceState);
        //   setContentView(R.layout.content_assessmentdetail);
        // TODO the email part was disabled to see if will process the info above it jumps right to here

        Button startBtn = (Button) findViewById(R.id.sendEmail);
        startBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendEmail();
            }
        });

    }

    /*
    endText = findViewById(R.id.editEndDate);
    mEndDate = findViewById(R.id.editEndDate);
    endDate = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
        int dayOfMonth) {
            // TODO Auto-generated method stub
            myCalendarEnd.set(Calendar.YEAR, year);
            myCalendarEnd.set(Calendar.MONTH, monthOfYear);
            myCalendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            String myFormat = "MM/dd/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

            updateLabelEnd();
        }

    };
*/


    protected void sendEmail() {
        Log.i("Send email", "");
        String[] TO = {""};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);

        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your subject");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Email message goes here");

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
            finish();
            Log.i("Finished sending email...", "");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(Assessment_Detail.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void updateLabelEnd() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        mEndText.setText(sdf.format(myCalendarEnd.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_assessment_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        int idActionSettings = R.id.action_settings;
        int idActionSettings1 = R.id.action_settings4;
        int idDelete = R.id.deleteA;

        int idSharing = R.id.sharing1;
        int idNotifications = R.id.notifications1;
        int idActionSettings3 = R.id.action_settings5;


        if (id == R.id.action_settings) {
            String myFormat = "MM/dd/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            Date myDate = null;
            try {
                myDate = sdf.parse(mDueDate.getText().toString());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            myCalendarEnd.setTime(myDate);
           // myCalanderEnd.setTime(endDate);



            long trigger = myCalendarEnd.getTimeInMillis();

            Intent intent = new Intent(Assessment_Detail.this, MyReceiver.class);
            intent.putExtra("dueDate", mDueDate.getText());
            intent.putExtra("message", "Assessment is due");

            PendingIntent sender = PendingIntent.getBroadcast(Assessment_Detail.this, ++MainActivity.numAlarms, intent, 0);
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            //  return true;


            //  if (id == R.id.action_settings3) {


            String end1 = mDueDate.getText().toString();

            String myFormat1 = "MM/dd/yy";
            SimpleDateFormat sdf1 = new SimpleDateFormat(myFormat, Locale.US);
            Date ourDate = null;
            try {
                ourDate = sdf1.parse(end1);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (id == R.id.action_settings4) {
                String end = endDate.toString();
                String myFormat2 = "MM/dd/yy";
                SimpleDateFormat sdf2 = new SimpleDateFormat(myFormat, Locale.US);
                Date mDueDate = null;
                try {
                    mDueDate = sdf.parse(end1);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                //   String s = mEditTermId.getText().toString();


                String s = mEditAssessmentId.getText().toString();

                int val = Integer.parseInt(s);
                AssessmentEntity newAssessment = new AssessmentEntity(0, "", "", "", 0, "", "", "", "");
                AssessmentViewModel mAssessmentViewModel = new ViewModelProvider(this).get(AssessmentViewModel.class);
                mAssessmentViewModel.insert(newAssessment);
                return true;

            }


            if (id == R.id.deleteA) {
                // if(numAssessments==0) {
                mAssessmentViewModel.getAllAssessments().observe(this, new Observer<List<AssessmentEntity>>() {
                    @Override
                    public void onChanged(@Nullable final List<AssessmentEntity> words) {
                        // Update the cached copy of the words in the adapter.
                        List<AssessmentEntity> filteredWords = new ArrayList<>();
                        for (AssessmentEntity p : words)
                            if (p.getAssessmentId() == getIntent().getIntExtra("assessmentId", 0))
//                                filteredWords.add(p);
                                mAssessmentViewModel.delete(p);
                        Toast.makeText(getApplicationContext(), "Assessment Deleted", Toast.LENGTH_LONG).show();
//                        // make a toast
//                        //adapter.setWords(words);
                    }
                });
            }
                /*
                else{
                    Toast.makeText(getApplicationContext(),"Can't delete a assessment with a course",Toast.LENGTH_LONG).show();// make another toast
                }

                 */


            if (id == R.id.sharing1) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "This is my message to send");

                sendIntent.putExtra(Intent.EXTRA_TEXT, "Send message course due date is");
                sendIntent.setType("text/plain");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
                return true;
            }
            if (id == R.id.notifications1) {
                Intent intent1 = new Intent(Assessment_Detail.this, MyReceiver.class);
                intent.putExtra("key", "This is a mini message ");
                PendingIntent sender1 = PendingIntent.getBroadcast(Assessment_Detail.this, ++MainActivity.numAlarms, intent, 0);
                AlarmManager alarmManager1 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                date = Long.parseLong(mills.getText().toString());
                alarmManager.set(AlarmManager.RTC_WAKEUP, date, sender);
                return true;
            }
            if (id == R.id.action_settings5) {
                Intent intent1 = new Intent(Assessment_Detail.this, MyReceiver.class);
                PendingIntent sender1 = PendingIntent.getBroadcast(Assessment_Detail.this, ++MainActivity.numAlarms, intent, 0);
                AlarmManager alarmManager1 = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1000, sender);
                return true;
            }

        }

        return super.onOptionsItemSelected(item);


    }


}