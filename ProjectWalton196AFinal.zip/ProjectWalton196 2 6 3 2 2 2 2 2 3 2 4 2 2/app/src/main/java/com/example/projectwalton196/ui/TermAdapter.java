package com.example.projectwalton196.ui;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.projectwalton196.CourseActivity;
import com.example.projectwalton196.Entities.TermEntity;
import com.example.projectwalton196.R;

import java.util.List;

public class TermAdapter extends RecyclerView.Adapter<TermAdapter.TermViewHolder> {
    class TermViewHolder extends RecyclerView.ViewHolder {
        private final TextView termListView;


        private TermViewHolder(View itemView) {
            super(itemView);
            termListView = itemView.findViewById(R.id.termTextView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //TermEntity(int termID, String termTitle, int termStartDate, int termEndDate)
                    int position = getAdapterPosition();
                    final TermEntity current = mTerm.get(position);
                    Intent intent = new Intent(context, CourseActivity.class);
                    intent.putExtra("termId", current.getTermId());
                    intent.putExtra("termTitle", current.getTermTitle()); // why is get not working here
                    intent.putExtra("termStartDate", current.getTermStartDate());
                    intent.putExtra("termEndDate", current.getTermEndDate());
                    intent.putExtra("position",position);

                    context.startActivity(intent);
                }
            });
        }
    }

    private final LayoutInflater mInflater;
    private final Context context;
    private List<TermEntity> mTerm; // Cached copy of words

    public TermAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context=context;
    }

    @Override
    public TermViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.term_list_item ,parent,false);//term_list_item, parent, false);
        return new TermViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(TermViewHolder holder, int position) {

        if (mTerm != null) {
            final TermEntity current = mTerm.get(position);
            holder.termListView.setText(current.getTermTitle());
           // holder.termItemView2.setText(current.getTermTitle());

        } else {

            // Covers the case of data not being ready yet.
            holder.termListView.setText("No Word");
          //  holder.termItemView2.setText("No Word");
        }
    }



    public void setWords(List<TermEntity> words) {
        mTerm= words;
        notifyDataSetChanged();
    }

    // getItemCount() is called many times, and when it is first called,
    // mWords has not been updated (means initially, it's null, and we can't return null).
    @Override
    public int getItemCount() {
        if (mTerm != null)
            return mTerm.size();
        else return 0;
    }

    }

