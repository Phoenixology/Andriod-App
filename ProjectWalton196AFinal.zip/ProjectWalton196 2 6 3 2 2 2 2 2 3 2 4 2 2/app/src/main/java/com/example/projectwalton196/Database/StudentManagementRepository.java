package com.example.projectwalton196.Database;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.projectwalton196.DAO.Assessments;
import com.example.projectwalton196.DAO.Course;
import com.example.projectwalton196.DAO.Term;
import com.example.projectwalton196.Entities.AssessmentEntity;
import com.example.projectwalton196.Entities.CourseEntity;
import com.example.projectwalton196.Entities.TermEntity;

import java.util.List;

public class StudentManagementRepository {
    private Assessments mAssessmentsDAO;
    private Course mCourseDAO;
    private Term mTermDAO;
    private LiveData<List<AssessmentEntity>> mAllAssessments;
    private LiveData<List<CourseEntity>> mAllAssociatedCourses;
    private LiveData<List<TermEntity>> mAllAssociatedTerms;
    private LiveData<List<AssessmentEntity>> mAllAssociatedAssessments;
    private LiveData<List<CourseEntity>> mAllCourses;
    private LiveData<List<TermEntity>> mAllTerms;

    private int courseId;
    private int assessmentId;
    private int termId;

    public StudentManagementRepository(Application application) {
        StudentManagementDatabase db = StudentManagementDatabase.getDatabase(application);
        mAssessmentsDAO = db.assessmentsDAO();
        mCourseDAO = db.courseDAO();
        mTermDAO = db.termDAO();

        mAllAssessments = mAssessmentsDAO.getAllAssessments();
        mAllCourses = mCourseDAO.getAllCourses();
        mAllTerms = mTermDAO.getAllTerms();
        mAllAssociatedCourses = mCourseDAO.getAllAssociatedCourses(termId);
        mAllAssociatedAssessments = mAssessmentsDAO.getAllAssociatedAssessments(courseId);
        int i = 0;


    }

    public LiveData<List<CourseEntity>> getAllCourses() {
        return mAllCourses;
    }

    public LiveData<List<CourseEntity>> getmAllAssociatedCourses(int termId) {
        return mAllAssociatedCourses;
    }

    public LiveData<List<AssessmentEntity>> getAllAssessments() {
        return mAllAssessments;
    }

    public LiveData<List<AssessmentEntity>> getAllAssociatedAssessments(int courseId) {
        return mAllAssociatedAssessments;
    }

    public LiveData<List<TermEntity>> getAllTerms() {
        return mAllTerms;
    }

    public LiveData<List<TermEntity>> getAllAssociatedTerms(int courseId) {
        return mAllAssociatedTerms;
    }

    public void insert(AssessmentEntity assessmentsEntity) {
        new insertAsyncTask1(mAssessmentsDAO).execute(assessmentsEntity);
    }


    private static class insertAsyncTask1 extends AsyncTask<AssessmentEntity, Void, Void> {

        private Assessments mAsyncTaskDao;

        insertAsyncTask1(Assessments dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final AssessmentEntity... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }

    public void delete(AssessmentEntity assessmentEntity) {
        new deleteAsyncTask1(mAssessmentsDAO).execute(assessmentEntity);
    }

    private static class deleteAsyncTask1 extends AsyncTask<AssessmentEntity, Void, Void> {
        private Assessments mAsyncTaskDao;

        deleteAsyncTask1(Assessments dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final AssessmentEntity... params) {
            mAsyncTaskDao.delete(params[0]);
            return null;
        }
    }


        public void insert(CourseEntity courseEntity) {
            new insertAsyncTask2(mCourseDAO).execute(courseEntity);  // relabel to assessments
        }


        private static class insertAsyncTask2 extends AsyncTask<CourseEntity, Void, Void> {

            private Course mAsyncTaskDao;

            insertAsyncTask2(Course dao) {
                mAsyncTaskDao = dao;
            }

            @Override
            protected Void doInBackground(final CourseEntity... params) {
                mAsyncTaskDao.insert(params[0]);
                return null;
            }
        }

        public void delete(CourseEntity courseEntity) {
            new deleteAsyncTask2(mCourseDAO).execute(courseEntity);
        }

        private static class deleteAsyncTask2 extends AsyncTask<CourseEntity, Void, Void> {
            private Course mAsyncTaskDao;

            deleteAsyncTask2(Course dao) {
                mAsyncTaskDao = dao;
            }

            @Override
            protected Void doInBackground(final CourseEntity... params) {
                mAsyncTaskDao.delete(params[0]);
                return null;
            }

        }


        public void insert(TermEntity termEntity) {
            new insertAsyncTask3(mTermDAO).execute(termEntity);
        }


        private static class insertAsyncTask3 extends AsyncTask<TermEntity, Void, Void> {

            private Term mAsyncTaskDao;

            insertAsyncTask3(Term dao) {
                mAsyncTaskDao = dao;
            }

            @Override
            protected Void doInBackground(final TermEntity... params) {
                mAsyncTaskDao.insert(params[0]);
                return null;
            }
        }

        public void delete(TermEntity termEntity) {
            new deleteAsyncTask(mTermDAO).execute(termEntity);
        }

        private static class deleteAsyncTask extends AsyncTask<TermEntity, Void, Void> {
            private Term mAsyncTaskDao;

            deleteAsyncTask(Term dao) {
                mAsyncTaskDao = dao;
            }

            @Override
            protected Void doInBackground(final TermEntity... params) {
                mAsyncTaskDao.delete(params[0]);
                return null;
            }


        }
/*
        public void execute(AssessmentEntity assessmentEntity) {

        }

        public void execute(CourseEntity courseEntity) {


        } */
    }

