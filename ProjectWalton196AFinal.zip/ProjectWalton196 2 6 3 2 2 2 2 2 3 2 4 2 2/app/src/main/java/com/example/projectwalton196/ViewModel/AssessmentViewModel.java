package com.example.projectwalton196.ViewModel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.projectwalton196.Database.StudentManagementRepository;
import com.example.projectwalton196.Entities.AssessmentEntity;

import java.util.List;


public class AssessmentViewModel extends AndroidViewModel {

    private int assessmentId;
    private int courseId;
    private int termId;


    private StudentManagementRepository mRepository;
    private LiveData<List<AssessmentEntity>> mAssociatedAssessments;
    private LiveData<List<AssessmentEntity>> mAllAssessments;

    public AssessmentViewModel(Application application, int courseId) {
        super(application);
        mRepository = new StudentManagementRepository(application);
        mAssociatedAssessments = mRepository.getAllAssociatedAssessments(courseId);//getAssociatedAssessments(courseId);
    }

    public AssessmentViewModel(Application application) {
        super(application);
        mRepository = new StudentManagementRepository(application);
        mAllAssessments = mRepository.getAllAssessments();
        mAssociatedAssessments = mRepository.getAllAssociatedAssessments(courseId);
    }

    public LiveData<List<AssessmentEntity>> getAssociatedAssessments(int courseId) {
        return mRepository.getAllAssociatedAssessments(courseId);
    }

    public LiveData<List<AssessmentEntity>> getAllAssessments() {
        return mAllAssessments;
    }

    public void insert(AssessmentEntity assessmentEntity) {
        mRepository.insert(assessmentEntity);
    }
    public void delete(AssessmentEntity assessmentEntity){ mRepository.delete(assessmentEntity);}

    public int lastID() { return mAllAssessments.getValue().size();


    }

/*
    public void delete(AssessmentEntity p) {

    }  */
}

