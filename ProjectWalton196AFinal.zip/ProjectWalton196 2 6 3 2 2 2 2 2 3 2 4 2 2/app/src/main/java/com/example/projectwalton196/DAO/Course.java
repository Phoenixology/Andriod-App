package com.example.projectwalton196.DAO;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Delete;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.projectwalton196.Entities.CourseEntity;

import java.util.List;


@Dao
public interface Course {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(CourseEntity course);

    @Query("DELETE FROM course_table")
    void deleteAll();

    @Delete
    void delete(CourseEntity course);

    @Query("SELECT * from course_table ORDER BY courseId ASC")
    LiveData<List<CourseEntity>> getAllCourses();

    @Query ("SELECT * FROM course_table WHERE courseId= :courseId ORDER BY courseId ASC")
    LiveData<List<CourseEntity>> getAllAssociatedCourses(int courseId);
}



