package com.example.projectwalton196.DAO;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.projectwalton196.Entities.AssessmentEntity;

import java.util.List;


@Dao
public interface Assessments {
    @Insert (onConflict = OnConflictStrategy.REPLACE)
    void insert(AssessmentEntity assessment);

    @Query("DELETE FROM assessments_table")
    void deleteAll();

    @Delete
    void delete(AssessmentEntity assessment);

    @Query("SELECT * FROM assessments_table ORDER BY assessmentId ASC")
    LiveData<List<AssessmentEntity>> getAllAssessments();

    @Query ("SELECT * FROM assessments_table WHERE assessmentId= :assessmentId ORDER BY assessmentId ASC")
    LiveData<List<AssessmentEntity>> getAllAssociatedAssessments(int assessmentId);


/*


// allowing the insert of the same word multiple times by passing a
    // conflict resolution strategy
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Assessments assessments);

    @Query("DELETE FROM assessments_table")
    void deleteAll();
*/

}



