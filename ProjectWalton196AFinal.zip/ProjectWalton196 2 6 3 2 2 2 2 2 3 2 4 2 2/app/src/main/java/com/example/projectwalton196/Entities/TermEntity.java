package com.example.projectwalton196.Entities;
import androidx.annotation.NonNull;
import androidx.room.*;

@Entity(tableName="term_table")
public class TermEntity {
    @PrimaryKey
    @NonNull
    private int termId;
    private String termTitle;
    private String termStartDate;
    private String termEndDate;




    @Override
    public String toString() {
        return "TermEntity{" +
                "termId= " + termId +
                "termTitle=" + termTitle +
                ", termStartDate='" + termStartDate + '\'' +
                ", termEndDate=" + termEndDate +
                '}';
    }

    public TermEntity(int termId, String termTitle, String termStartDate, String termEndDate) {
        this.termId = termId;
        this.termTitle = termTitle;
        this.termStartDate = termStartDate;
        this.termEndDate = termEndDate;

    }
    public int getTermId() {
        return termId;
    }
    public void setTermId(int termId) {
            this.termId = termId;}


    public void setTermTitle(String termTitle) {
        this.termTitle = termTitle;}

    public String getTermTitle() {
        return termTitle;
    }


    public String getTermStartDate() { return termStartDate;}


    public void setTermStartDate(String termStartDate) {
        this.termStartDate = termStartDate;}

    public String getTermEndDate() { return termEndDate;}


    public void setTermEndDate(String termEndDate){
        this.termEndDate = termEndDate;}










}
