package com.example.projectwalton196.Entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName="assessments_table")
public class AssessmentEntity {

        @PrimaryKey
        private int assessmentId;
        private String assessmentTitle;
        private String objectiveAssessment;
        private String performanceAssessment;
        private int courseId;
        private String assessmentDueDate;
        private String courseNotes;
        private String sharingFeatures;
        private String setAlert;





    @Override
        public String toString() {
            return "AssessmentEntity{" +
                    ",assessmentId =" + assessmentId +
                    "assessmentTitle=" + assessmentTitle +
                    "objectiveAssessment=" +objectiveAssessment+
                    "performanceAssessment= "+ performanceAssessment+
                    ", courseId =" + courseId +
                    ", assessmentDueDate='" + assessmentDueDate + '\'' +
                    ", courseNotes=" + courseNotes +
                    ", sharingFeatures=" + sharingFeatures +
                    " setAlert = "+ setAlert+
                    '}';
        }

        public AssessmentEntity( int assessmentId, String assessmentTitle ,String objectiveAssessment, String performanceAssessment,int courseId, String assessmentDueDate, String courseNotes, String sharingFeatures, String setAlert) {

            this.assessmentId = assessmentId;
            this.assessmentTitle = assessmentTitle;
            this.objectiveAssessment = objectiveAssessment;
            this.performanceAssessment = performanceAssessment;
            this.courseId = courseId;
            this.assessmentDueDate = assessmentDueDate;
            this.courseNotes = courseNotes;
            this.sharingFeatures = sharingFeatures;
            this.setAlert = setAlert;
        }
        public int getCourseId(){return courseId;}

    public int getAssessmentId(){return assessmentId;}

        public String getAssessmentTitle() {
            return assessmentTitle;
        }
        public void setAssessmentTitle(String assessmentTitle) {
            this.assessmentTitle = assessmentTitle;}

    public void setAssessmentId(int assessmentId) {
        this.assessmentId = assessmentId;
    }

    public String getObjectiveAssessment() {
        return objectiveAssessment;
    }

    public void setObjectiveAssessment(String objectiveAssessment) {
        this.objectiveAssessment = objectiveAssessment;
    }

    public String getPerformanceAssessment() {
        return performanceAssessment;
    }

    public void setPerformanceAssessment(String performanceAssessment) {
        this.performanceAssessment = performanceAssessment;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setAssessmentDueDate(String assessmentDueDate) {
        this.assessmentDueDate = assessmentDueDate;
    }

    public String getSetAlert() {
        return setAlert;
    }

    public void setSetAlert(String setAlert) {
        this.setAlert = setAlert;
    }

    public String getAssessmentDueDate() { return assessmentDueDate;}

        public String getCourseNotes() {
        return courseNotes;
    }
        public void setCourseNotes(String courseNotes) {
        this.courseNotes = courseNotes;}

        public String getSharingFeatures() {
        return sharingFeatures;
    }
        public void setSharingFeatures(String sharingFeatures) {
        this.sharingFeatures = sharingFeatures;}



    }


